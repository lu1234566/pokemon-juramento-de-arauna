# Exportação GBA — Pokémon Juramento de Araúna

Pacote concluído em 09/08/2026 para integração com uma base Pokémon Emerald/Gen III.

## Conteúdo

- `front/`: 386 sprites normais `64×128`, com dois frames `64×64` empilhados;
- `shiny/`: 386 sprites Shiny `64×128`;
- `back/`: 386 backsprites `64×64` em vista traseira;
- `pokedex.json`: manifesto canônico dos IDs 001–386;
- `manifest.csv` e `manifest.json`: nomes, contagens de cores e hashes SHA-256;
- `SHA256SUMS.txt`: verificação de integridade das 1.158 imagens;
- `QA_RESUMO.md`, `qa_report.json` e `qa_issues.csv`: validação técnica;
- `qa_sheets/`: folhas de conferência visual por lote.

## Especificação aplicada

- PNG indexado de 8 bits;
- índice de paleta `0` reservado para transparência;
- no máximo 15 cores opacas por arquivo;
- cores ajustadas à precisão BGR555 do GBA;
- nenhuma semitransparência, interpolação, blur ou dithering;
- encaixe por vizinho mais próximo;
- iluminação e silhueta das artes aprovadas preservadas;
- escala baseada no estágio evolutivo, altura e ocupação das sprites já aprovadas;
- Normal e Shiny compartilham a mesma matriz de índices: somente os valores da paleta mudam;
- quando não havia uma segunda animação aprovada, o frame principal foi duplicado;
- arquivos identificados por `NNN_slug`; o `id` numérico continua sendo a chave primária.

## Nomes

- frente normal: `NNN_slug.png`;
- frente Shiny: `NNN_slug_shiny.png`;
- costas: `NNN_slug_back.png`.

## Integração

Use `id` como chave primária. Não use somente o nome ou slug sem o prefixo numérico,
pois existem nomes que normalizam para o mesmo texto. O importador do projeto pode
converter estes PNGs indexados para tiles/paletas 4bpp da base Emerald sem precisar
reconstruir transparência ou reduzir cores.

As artes-mestre em alta resolução permanecem separadas e não foram sobrescritas.
