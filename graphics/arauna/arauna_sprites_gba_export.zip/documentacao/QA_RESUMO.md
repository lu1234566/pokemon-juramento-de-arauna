# Controle de qualidade — Exportação GBA Araúna

- IDs conferidos: **386/386**
- Arquivos conferidos: **1158/1.158**
- Dimensões-alvo: frente/Shiny **64×128**; costas **64×64**
- Formato: PNG indexado, índice 0 transparente
- Limite: até 15 cores opacas, paleta ajustada a BGR555
- Pares Normal/Shiny com matriz de índices idêntica: **386/386**
- Shinies visualmente idênticas ao Normal: **0**
- Ocorrências técnicas pendentes: **0**
- Frentes com frame duplicado por falta de animação aprovada: **386**

O arquivo `qa_report.json` contém a inspeção por ID; `qa_issues.csv` lista somente ocorrências acionáveis.
