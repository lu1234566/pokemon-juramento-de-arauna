# Padrão de exportação GBA — Pokémon Juramento de Araúna

Atualizado em 09/08/2026 após a exportação completa dos IDs 001–386.

## Frentes normal e Shiny

- canvas `64×128 px`;
- dois frames `64×64 px` empilhados verticalmente;
- frame superior: idle principal;
- frame inferior: idle secundário; duplicar o principal quando não houver animação aprovada;
- PNG indexado, índice de paleta `0` transparente;
- até 15 cores opacas, sem semitransparência;
- paleta compatível com BGR555;
- vizinho mais próximo, sem antialiasing, blur, gradientes adicionais ou dithering;
- Normal e Shiny usam a mesma matriz de índices e máscara; somente a paleta muda;
- normal: `NNN_slug.png`;
- Shiny: `NNN_slug_shiny.png`.

## Costas

- canvas `64×64 px`;
- uma criatura em vista traseira/três-quartos;
- PNG indexado, índice `0` transparente;
- até 15 cores opacas, paleta BGR555;
- sem semitransparência, antialiasing, blur ou dithering;
- `NNN_slug_back.png`.

## Escala e alinhamento

- silhueta legível em escala 1×;
- criatura centralizada, com base próxima ao limite inferior e margem segura;
- efeitos aprovados preservados sem corte;
- escala coerente com estágio evolutivo, altura e sprites já aprovadas;
- não preencher arbitrariamente todo o canvas.

## Identidade e preservação

- usar o ID 001–386 como chave primária;
- manter o slug numerado como chave técnica legível;
- preservar as artes-mestre e o histórico em alta resolução;
- gerar e integrar somente a cópia de exportação GBA.
