# Relatório de exportação GBA — Pokémon Juramento de Araúna

Data: 09/08/2026

## Resultado

- 386/386 frentes normais exportadas;
- 386/386 frentes Shiny exportadas;
- 386/386 backsprites exportadas;
- total: 1.158 PNGs indexados;
- IDs 001–386 completos, sem lacunas, duplicatas ou divergências de slug;
- artes-mestre do Drive preservadas sem sobrescrita.

## Transformação aplicada

As 265 frentes normais e 265 Shinies que já usavam canvas `64×128` tiveram o desenho
preservado e foram normalizadas para paleta indexada. As 121 frentes normais e 121
Shinies maiores foram reenquadradas com escala canônica e amostragem por vizinho mais
próximo. As 386 costas foram convertidas para `64×64` a partir das vistas traseiras
aprovadas.

Cada par Normal/Shiny passou a compartilhar exatamente a mesma matriz de índices,
silhueta, enquadramento e máscara de transparência. A versão Shiny muda somente os
valores da paleta.

## Validação técnica

- dimensões corretas: 1.158/1.158;
- modo PNG indexado: 1.158/1.158;
- índice 0 transparente: 1.158/1.158;
- no máximo 15 cores opacas: 1.158/1.158;
- paletas compatíveis com precisão BGR555: 1.158/1.158;
- pares Normal/Shiny com matriz idêntica: 386/386;
- Shinies visualmente idênticas ao Normal: 0;
- ocorrências técnicas pendentes: 0.

## Revisão visual

Foram geradas oito folhas de conferência, uma por lote de 50 IDs, mais uma visão geral
dos 386 IDs. A inspeção verificou leitura da silhueta, centralização, margem inferior,
preservação de efeitos, diferenciação Shiny e coerência da vista traseira. Não foram
encontrados efeitos cortados, fundos incorporados ou sprites vazias no pacote final.

## Entrega

O pacote inclui as três pastas individuais, um ZIP completo, oito ZIPs por lote,
manifestos CSV/JSON, hashes SHA-256, folhas de QA e o `pokedex.json` canônico.
